STARLIGHT PLEOS — 실제 웹 시연 영상 편집 프로젝트

출력: ../STARLIGHT_PLEOS_demo.mp4
설명 자막: ../STARLIGHT_PLEOS_demo.srt
1920×1080, 25fps, H.264 yuv420p / AAC 48kHz stereo.
실제 길이는 resolved-timeline.json과 final-probe.json에 기록합니다.

이 영상은 실제 웹 프로토타입의 조작 녹화입니다. 원본 브라우저 영상은
무음이며, 한국어 설명 자막과 별도의 허가된 배경음악을 편집해 넣었습니다.
실제 앱 내레이션/스피커 출력을 녹음한 것으로 표시하지 않습니다.
외부 음성 연결이 제한된 환경의 전체 대본·읽기 완료 경로를 그대로 보여줍니다.

원본 UI를 잘라 확대하거나, 재생 상태/진행률을 모의하거나, 조작 속도를
배속하지 않았습니다. 선택한 구간은 모두 1.0×이며, 대표 동작 구간을
컷으로 연결했습니다. 각 장은 실제로 조작한 별도 브라우저 녹화로
구성되므로, 한 번에 이어 찍은 무편집 녹화라고 표시하지 않습니다.
차량 제어와 공동 감상은 화면에 표시된 웹/동일 브라우저 시연 범위입니다.
실제 Pleos SDK 연결이나 실차 제어의 증거가 아닙니다.

소스: ../raw/*-r2.webm 및 ../raw/08-window-midstop-r3.webm.
선택 구간/편집 의도/설명 자막: edit.json.
정확한 소스→완성 영상 시간표/해시/미디어 정보: resolved-timeline.json.
설명 자막은 실제 음성의 받아쓰기가 아닌 화면 단계 안내입니다.
MP4에는 자막이 이미 포함되어 있어, 플레이어에서 SRT를 추가로 켜면
같은 문구가 겹칩니다. SRT는 재편집과 별도 접근성 참고용입니다.

재현 요구사항:
- Python 3.11 이상
- FFmpeg/FFprobe (libx264, AAC, libass 지원)
- 시스템 폰트 Noto Sans CJK KR
- 이 project 폴더와 raw 폴더를 같은 video 상위 폴더 아래에 유지

재생성:
  python project/render_video.py --output STARLIGHT_PLEOS_demo-v2.mp4

출력 이름이 이미 존재하면 중단하므로, 수정본은 새 파일명을 지정합니다.
render_video.py는 source_in/out을 25fps 프레임 경계에 맞추고, 실제
녹화 길이보다 긴 wall-clock 메타데이터를 기록 파일 끝 0.2초 전으로
제한합니다. 내레이션/화면 속도는 변경하지 않습니다.

영상 입력은 Chromium VP8의 full-range BT.470BG 매트릭스에서
SDR Rec.709 limited-range로 변환하며, 화면 크기와 종횡비는 유지합니다.
코드·명령·렌더 로그·디코드 로그·음량 측정은 함께 보관합니다.

검수 한계:
디코딩/메타데이터/프레임·자막·컷 경계 검수와 재생 시간 확인을 수행합니다.
실제 스피커/헤드폰에서의 전체 음악 청취 검증은 별도입니다.
폰·차량의 실제 하드웨어 재생은 이 편집 검수의 대상이 아닙니다.

배경음악의 저작자, 라이선스, 출처, 변환 범위는 CREDITS.txt를 참고하세요.
