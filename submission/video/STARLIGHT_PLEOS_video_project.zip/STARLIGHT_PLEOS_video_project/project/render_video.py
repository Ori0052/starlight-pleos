#!/usr/bin/env python3
"""Render truthful, natural-speed product screen recordings with editorial captions."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import subprocess
from fractions import Fraction
from pathlib import Path

HERE = Path(__file__).resolve().parent
VIDEO = HERE.parent
FPS = 25


def run(args, log=None):
    result = subprocess.run([str(x) for x in args], capture_output=True, text=True)
    if log:
        Path(log).write_text(result.stdout + result.stderr)
    if result.returncode:
        raise RuntimeError(f"{args[0]} failed ({result.returncode}): {result.stderr[-3000:]}")
    return result.stdout


def probe(path):
    return json.loads(run(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", path]))


def ass_time(seconds):
    ticks = round(seconds * 100)
    return f"{ticks//360000}:{ticks//6000%60:02}:{ticks//100%60:02}.{ticks%100:02}"


def srt_time(seconds):
    ticks = round(seconds * 1000)
    return f"{ticks//3600000:02}:{ticks//60000%60:02}:{ticks//1000%60:02},{ticks%1000:03}"


def escape_ass(text):
    return text.replace("\\", "\\\\").replace("{", r"\{").replace("}", r"\}").replace("\n", r"\N")


def write_captions(cues):
    header = """[Script Info]
Title: STARLIGHT PLEOS — editorial UI annotations, not spoken subtitles
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
ScaledBorderAndShadow: yes
WrapStyle: 2

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Noto Sans CJK KR,32,&H00FFFFFF,&H00FFFFFF,&H90110B05,&H90110B05,0,0,0,0,100,100,0,0,3,9,0,5,70,70,0,1
Style: Credit,Noto Sans CJK KR,24,&H00D9E5F4,&H00FFFFFF,&H90110B05,&H90110B05,0,0,0,0,100,100,0,0,3,7,0,5,70,70,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    lines = []
    srt = []
    prior_end = 0
    for i, cue in enumerate(cues, 1):
        assert 0 <= cue["start"] < cue["end"]
        assert cue["start"] >= prior_end - .001, "Do not stack editorial captions"
        prior_end = cue["end"]
        x, y = cue.get("position", [960, 926])
        style = cue.get("style", "Default")
        text = escape_ass(cue["text"])
        lines.append(f"Dialogue: 0,{ass_time(cue['start'])},{ass_time(cue['end'])},{style},,0,0,0,,{{\\an5\\pos({x},{y})}}{text}")
        srt.append(f"{i}\n{srt_time(cue['start'])} --> {srt_time(cue['end'])}\n{cue['text']}\n")
    (HERE / "annotations.ass").write_text(header + "\n".join(lines) + "\n")
    (VIDEO / "STARLIGHT_PLEOS_demo.srt").write_text("\n".join(srt))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="STARLIGHT_PLEOS_demo.mp4")
    parser.add_argument("--edit", default="edit.json")
    args = parser.parse_args()
    edit = json.loads((HERE / args.edit).read_text())
    matched_font = run(["fc-match", "Noto Sans CJK KR", "-f", "%{family}"])
    if "Noto Sans CJK" not in matched_font:
        raise RuntimeError("Install Noto Sans CJK KR before rendering; do not silently substitute fonts")
    inventory = []
    timeline = []
    total_frames = 0
    for beat in edit["segments"]:
        path = (HERE / beat["file"]).resolve()
        info = probe(path)
        stream = next(s for s in info["streams"] if s["codec_type"] == "video")
        assert (stream["width"], stream["height"]) == (1920, 1080)
        assert not any(s["codec_type"] == "audio" for s in info["streams"]), "Screen source must remain explicitly silent"
        source_length = float(info["format"]["duration"])
        start_frame = math.ceil(Fraction(str(beat["source_in"])) * FPS)
        end_frame = min(math.floor(Fraction(str(beat["source_out"])) * FPS), math.floor((Fraction(info["format"]["duration"])-Fraction(1,5)) * FPS))
        assert end_frame > start_frame
        duration_frames = end_frame - start_frame
        item = dict(beat, source_in=start_frame/FPS, source_out=end_frame/FPS,
                    sequence_start=total_frames/FPS,
                    sequence_end=(total_frames+duration_frames)/FPS,
                    duration_frames=duration_frames)
        timeline.append(item)
        total_frames += duration_frames
        inventory.append({"id": beat["id"], "file": beat["file"], "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                          "source_duration": source_length, "stream": stream})
    duration = total_frames / FPS
    cues = edit["cues"]
    assert cues[-1]["end"] <= duration + .001
    write_captions(cues)
    (HERE / "resolved-timeline.json").write_text(json.dumps({"fps": FPS, "duration": duration, "frames": total_frames, "segments": timeline, "inventory": inventory}, ensure_ascii=False, indent=2))
    output = VIDEO / args.output
    assert not output.exists(), "Use a new output name for a revised encode"

    inputs = []
    for beat in timeline:
        inputs += ["-i", str((HERE / beat["file"]).resolve())]
    music = (HERE / edit["music"]["file"]).resolve()
    assert float(probe(music)["format"]["duration"]) >= duration, "Music source must cover the actual edit"
    inputs += ["-i", str(music)]
    graphs = []
    for i, beat in enumerate(timeline):
        # Timestamps change origin only; every retained UI action stays at 1.0x.
        # Chromium VP8 explicitly reports full-range BT.470BG; preserve displayed
        # RGB appearance while conforming matrix/range to SDR Rec.709 video.
        graphs.append(f"[{i}:v]trim=start={beat['source_in']:.3f}:end={beat['source_out']:.3f},setpts=PTS-STARTPTS,fps={FPS},scale=in_range=pc:out_range=tv:in_color_matrix=bt601:out_color_matrix=bt709,format=yuv420p[v{i}]")
    video_labels = "".join(f"[v{i}]" for i in range(len(timeline)))
    subtitle_path = (HERE / "annotations.ass").as_posix().replace(":", r"\:").replace("'", r"\'")
    graphs.append(f"{video_labels}concat=n={len(timeline)}:v=1:a=0[sequence]")
    graphs.append(f"[sequence]ass=filename='{subtitle_path}'[picture]")
    gain = edit["music"].get("gain", .16)
    graphs.append(f"[{len(timeline)}:a]atrim=start=0:end={duration:.3f},asetpts=PTS-STARTPTS,aresample=48000,aformat=channel_layouts=stereo,volume={gain},afade=t=in:d=1.2,afade=t=out:st={max(0,duration-3):.3f}:d=3[music]")
    command = ["ffmpeg", "-nostdin", "-hide_banner", "-n", *inputs, "-filter_complex", ";".join(graphs),
               "-map", "[picture]", "-map", "[music]", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-threads", "2",
               "-pix_fmt", "yuv420p", "-r", str(FPS), "-color_range", "tv", "-colorspace", "bt709", "-color_trc", "bt709", "-color_primaries", "bt709",
               "-c:a", "aac", "-b:a", "160k", "-ar", "48000", "-movflags", "+faststart",
               "-metadata", "title=STARLIGHT PLEOS — 별빛 드라이브 실제 웹 시연",
               "-metadata", "comment=Actual silent web UI recordings, natural speed, editorial Korean annotations. Separate licensed music bed: Clair de lune, Claude Debussy; piano/recording Laurens Goedhart (2011), CC BY 3.0. No recorded application narration or Pleos SDK connection is asserted.", str(output)]
    (HERE / "render-command.json").write_text(json.dumps(command, ensure_ascii=False, indent=2))
    run(command, HERE / "render.log")
    report = probe(output)
    (HERE / "final-probe.json").write_text(json.dumps(report, ensure_ascii=False, indent=2))
    run(["ffmpeg", "-nostdin", "-v", "error", "-i", output, "-f", "null", "-"], HERE / "decode.log")
    run(["ffmpeg", "-nostdin", "-hide_banner", "-i", output, "-vn", "-af", "ebur128=peak=true", "-f", "null", "-"], HERE / "loudness.log")
    print(json.dumps({"output": str(output), "duration": duration, "frames": total_frames, "decode": "passed"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
